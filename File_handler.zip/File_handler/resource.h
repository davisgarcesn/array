//Libraries
//Description of function
//
#include <stdio.h>
#include <stdlib.h>
//#include "resource.c"
#include <sys/types.h>
#include <unistd.h>


